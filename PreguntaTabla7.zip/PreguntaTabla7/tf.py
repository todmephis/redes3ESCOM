#!/usr/bin/python

import os, sys

ip = raw_input("Introduce los dos primeros octetos: ")

os.system("tftp 192.168.1.2 << TFTP\n get startup-config /var/lib/tftpboot/r1\nquit\n TFTP")
os.system("tftp "+ip+".1.10 << TFTP\n get startup-config /var/lib/tftpboot/r2\nquit\n TFTP")
os.system("tftp "+ip+".1.22 << TFTP\n get startup-config /var/lib/tftpboot/r3\nquit\n TFTP")
os.system("tftp "+ip+".1.18 << TFTP\n get startup-config /var/lib/tftpboot/r4\nquit\n TFTP")
os.system("tftp "+ip+".1.30 << TFTP\n get startup-config /var/lib/tftpboot/r5\nquit\n TFTP")
os.system("tftp "+ip+".1.6 << TFTP\n get startup-config /var/lib/tftpboot/r6\nquit\n TFTP")
os.system("tftp "+ip+".1.42 << TFTP\n get startup-config /var/lib/tftpboot/r7\nquit\n TFTP")
os.system("tftp "+ip+".1.14 << TFTP\n get startup-config /var/lib/tftpboot/r8\nquit\n TFTP")
os.system("tftp "+ip+".1.50 << TFTP\n get startup-config /var/lib/tftpboot/r9\nquit\n TFTP")
os.system("tftp "+ip+".1.54 << TFTP\n get startup-config /var/lib/tftpboot/r10\nquit\n TFTP")