import getpass
import keyboard
import telnetlib
import json
import sys
import os
import time

HOST = (sys.argv[1])
print (sys.argv[1])
password="cisco"
tn=telnetlib.Telnet(HOST)
tn.read_until(b"Username: ")
tn.write(b'cisco' + b"\n")
if password:
		#time.sleep(2)
		tn.read_until(b"Password: ")
		tn.write(b'cisco' + b"\n")
tn.write(b"en\n")
tn.read_until(b"Password: ")
tn.write(b"cisco\n")
tn.write(b"copy tftp: startup-config\n")
tn.write(b"192.168.1.1\n")
tn.write(b"r"+sys.argv[2].encode('ascii')+b"\n")
tn.write(b"\n")
tn.write(b"exit\n")
tn.read_all().decode('ascii')