import getpass
import keyboard
import telnetlib
import json
import sys
import os
import time




lista=[]
#Este archivo es donde tienes guardado los host que contestaron el script de la pregunta 1 de la tabla 3
i=0
ip=str(input("Introduce los dos primeros octetos del nuevo dominio: "))
anti=str(input("Introduce los dos primeros octetos del anterior dominio: "))
ips=[]

with open ('1/r1','r') as f:
	r1 =[linea.split() for linea in f]

with open ('1/r2','r') as f:
	r2 =[linea.split() for linea in f]

with open ('1/r3','r') as f:
	r3 =[linea.split() for linea in f]

with open ('1/r4','r') as f:
	r4 =[linea.split() for linea in f]

with open ('1/r5','r') as f:
	r5 =[linea.split() for linea in f]

with open ('1/r6','r') as f:
	r6 =[linea.split() for linea in f]

with open ('1/r7','r') as f:
	r7 =[linea.split() for linea in f]

with open ('1/r8','r') as f:
	r8 =[linea.split() for linea in f]

with open ('1/r9','r') as f:
	r9 =[linea.split() for linea in f]

with open ('1/r10','r') as f:
	r10 =[linea.split() for linea in f]
#print str(va)
ips.append(r1[55][2])
ips.append(r2[55][2])
ips.append(r3[55][2])
ips.append(r4[55][2])
ips.append(r5[55][2])
ips.append(r6[55][2])
ips.append(r7[55][2])
ips.append(r8[55][2])
ips.append(r9[55][2])
ips.append(r10[55][2])
print (ips)
#print (r1[54])
#r1[56][2]=ip+r1[56][2][len(r1[56][2])-4:len(r1[56][2])]
#r1[56][2]=ip+r1[56][2][len(r1[56][2])-5:len(r1[56][2])]
r1[61][2]=ip+r1[61][2][len(r1[61][2])-4:len(r1[61][2])]
r1[62][2]=ip+r1[62][2][len(r1[62][2])-5:len(r1[62][2])]
r1[108][2]=ip+r1[108][2][len(r1[108][2])-4:len(r1[108][2])]
r1[109][2]=ip+r1[109][2][len(r1[109][2])-5:len(r1[109][2])]
#r1[129][1]=ip+r1[129][1][len(r1[129][1])-4:len(r1[129][1])]
r1[128][1]=ip+r1[128][1][len(r1[128][1])-4:len(r1[128][1])]
r1[127][1]=ip+r1[127][1][len(r1[127][1])-4:len(r1[127][1])]

print(r1[55])
print(r1[61])
print(r1[62])
print(r1[108])
print(r1[109])
print(r1[128])
print(r1[127])


r2[55][2]=ip+r2[55][2][len(r2[55][2])-5:len(r2[55][2])]
r2[56][2]=ip+r2[56][2][len(r2[56][2])-5:len(r2[56][2])]
r2[62][2]=ip+r2[62][2][len(r2[62][2])-5:len(r2[62][2])]
r2[63][2]=ip+r2[63][2][len(r2[63][2])-5:len(r2[63][2])]
r2[109][2]=ip+r2[109][2][len(r2[109][2])-5:len(r2[109][2])]
r2[110][2]=ip+r2[110][2][len(r2[110][2])-5:len(r2[110][2])]
r2[128][1]=ip+r2[128][1][len(r2[128][1])-4:len(r2[128][1])]
r2[129][1]=ip+r2[129][1][len(r2[129][1])-5:len(r2[129][1])]
r2[130][1]=ip+r2[130][1][len(r2[130][1])-5:len(r2[130][1])]

print(r2[55])
print(r2[56])
print(r2[62])
print(r2[63])
print(r2[109])
print(r2[110])
print(r2[128])
print(r2[129])
print(r2[130])

r3[55][2]=ip+r3[55][2][len(r3[55][2])-5:len(r3[55][2])]
r3[56][2]=ip+r3[56][2][len(r3[56][2])-5:len(r3[56][2])]
r3[62][2]=ip+r3[62][2][len(r3[62][2])-5:len(r3[62][2])]
r3[63][2]=ip+r3[63][2][len(r3[63][2])-5:len(r3[63][2])]
r3[109][2]=ip+r3[109][2][len(r3[109][2])-5:len(r3[109][2])]
r3[110][2]=ip+r3[110][2][len(r3[110][2])-5:len(r3[110][2])]
r3[128][1]=ip+r3[128][1][len(r3[128][1])-5:len(r3[128][1])]
r3[129][1]=ip+r3[129][1][len(r3[129][1])-5:len(r3[129][1])]
r3[130][1]=ip+r3[130][1][len(r3[130][1])-5:len(r3[130][1])]

print(r3[55])
print(r3[56])
print(r3[62])
print(r3[63])
print(r3[109])
print(r3[110])
print(r3[128])
print(r3[129])
print(r3[130])


r4[55][2]=ip+r4[55][2][len(r4[55][2])-5:len(r4[55][2])]
r4[56][2]=ip+r4[56][2][len(r4[56][2])-5:len(r4[56][2])]
r4[62][2]=ip+r4[62][2][len(r4[62][2])-5:len(r4[62][2])]
r4[63][2]=ip+r4[63][2][len(r4[63][2])-5:len(r4[63][2])]
r4[109][2]=ip+r4[109][2][len(r4[109][2])-5:len(r4[109][2])]
r4[110][2]=ip+r4[110][2][len(r4[110][2])-5:len(r4[110][2])]
r4[116][2]=ip+r4[116][2][len(r4[116][2])-5:len(r4[116][2])]
r4[117][2]=ip+r4[117][2][len(r4[117][2])-5:len(r4[117][2])]
r4[128][1]=ip+r4[128][1][len(r4[128][1])-5:len(r4[128][1])]
r4[129][1]=ip+r4[129][1][len(r4[129][1])-5:len(r4[129][1])]
r4[130][1]=ip+r4[130][1][len(r4[130][1])-5:len(r4[130][1])]
r4[131][1]=ip+r4[131][1][len(r4[131][1])-5:len(r4[131][1])]
print("r4")

print(r4[55])
print(r4[56])
print(r4[62])
print(r4[63])
print(r4[109])
print(r4[110])
print(r4[116])
print(r4[117])
print(r4[128])
print(r4[129])
print(r4[130])
print(r4[131])


r5[55][2]=ip+r5[55][2][len(r5[55][2])-5:len(r5[55][2])]
r5[56][2]=ip+r5[56][2][len(r5[56][2])-5:len(r5[56][2])]
r5[62][2]=ip+r5[62][2][len(r5[62][2])-5:len(r5[62][2])]
r5[63][2]=ip+r5[63][2][len(r5[63][2])-5:len(r5[63][2])]
r5[109][2]=ip+r5[109][2][len(r5[109][2])-5:len(r5[109][2])]
r5[110][2]=ip+r5[110][2][len(r5[110][2])-5:len(r5[110][2])]
r5[128][1]=ip+r5[128][1][len(r5[128][1])-5:len(r5[128][1])]
r5[129][1]=ip+r5[129][1][len(r5[129][1])-5:len(r5[129][1])]
r5[130][1]=ip+r5[130][1][len(r5[130][1])-5:len(r5[130][1])]
print("r5")

print(r5[55])
print(r5[56])
print(r5[62])
print(r5[63])
print(r5[109])
print(r5[110])
print(r5[128])
print(r5[129])
print(r5[130])


r6[55][2]=ip+r6[55][2][len(r6[55][2])-4:len(r5[55][2])]
r6[56][2]=ip+r6[56][2][len(r6[56][2])-5:len(r5[56][2])]
r6[62][2]=ip+r6[62][2][len(r6[62][2])-5:len(r5[62][2])]
r6[63][2]=ip+r6[63][2][len(r6[63][2])-5:len(r5[63][2])]
r6[110][2]=ip+r6[110][2][len(r6[110][2])-5:len(r6[110][2])]
r6[111][2]=ip+r6[111][2][len(r6[111][2])-5:len(r6[111][2])]
r6[129][1]=ip+r6[129][1][len(r6[129][1])-4:len(r6[129][1])]
r6[130][1]=ip+r6[130][1][len(r6[130][1])-5:len(r6[130][1])]
r6[131][1]=ip+r6[131][1][len(r6[131][1])-5:len(r6[131][1])]
print("r6")
print(r6[55])
print(r6[56])
print(r6[62])
print(r6[63])
print(r6[110])
print(r6[111])
print(r6[129])
print(r6[130])
print(r6[131])

r7[55][2]=ip+r7[55][2][len(r7[55][2])-5:len(r7[55][2])]
r7[56][2]=ip+r7[56][2][len(r7[56][2])-5:len(r7[56][2])]
r7[62][2]=ip+r7[62][2][len(r7[62][2])-5:len(r7[62][2])]
r7[63][2]=ip+r7[63][2][len(r7[63][2])-5:len(r7[63][2])]
r7[109][2]=ip+r7[109][2][len(r7[109][2])-5:len(r7[109][2])]
r7[110][2]=ip+r7[110][2][len(r7[110][2])-5:len(r7[110][2])]
r7[128][1]=ip+r7[128][1][len(r7[128][1])-5:len(r7[128][1])]
r7[129][1]=ip+r7[129][1][len(r7[129][1])-5:len(r7[129][1])]
r7[130][1]=ip+r7[130][1][len(r7[130][1])-5:len(r7[130][1])]

print(r7[55])
print(r7[56])
print(r7[62])
print(r7[63])
print(r7[109])
print(r7[110])
print(r7[128])
print(r7[129])
print(r7[130])


r8[55][2]=ip+r8[55][2][len(r8[55][2])-5:len(r8[55][2])]
r8[56][2]=ip+r8[56][2][len(r8[56][2])-5:len(r8[56][2])]
r8[62][2]=ip+r8[62][2][len(r8[62][2])-5:len(r8[62][2])]
r8[63][2]=ip+r8[63][2][len(r8[63][2])-5:len(r8[63][2])]
r8[109][2]=ip+r8[109][2][len(r8[109][2])-5:len(r8[109][2])]
r8[110][2]=ip+r8[110][2][len(r8[110][2])-5:len(r8[110][2])]
r8[126][1]=ip+r8[126][1][len(r8[126][1])-5:len(r8[126][1])]
r8[127][1]=ip+r8[127][1][len(r8[127][1])-5:len(r8[127][1])]
r8[128][1]=ip+r8[128][1][len(r8[128][1])-5:len(r8[128][1])]

print(r8[55])
print(r8[56])
print(r8[62])
print(r8[63])
print(r8[109])
print(r8[110])
print(r8[126])
print(r8[127])
print(r8[128])


r9[55][2]=ip+r9[55][2][len(r9[55][2])-5:len(r9[55][2])]
r9[56][2]=ip+r9[56][2][len(r9[56][2])-5:len(r9[56][2])]
r9[62][2]=ip+r9[62][2][len(r9[62][2])-5:len(r9[62][2])]
r9[63][2]=ip+r9[63][2][len(r9[63][2])-5:len(r9[63][2])]
r9[109][2]=ip+r9[109][2][len(r9[109][2])-5:len(r9[109][2])]
r9[110][2]=ip+r9[110][2][len(r9[110][2])-5:len(r9[110][2])]
r9[128][1]=ip+r9[128][1][len(r9[128][1])-5:len(r9[128][1])]
r9[129][1]=ip+r9[129][1][len(r9[129][1])-5:len(r9[129][1])]
r9[130][1]=ip+r9[130][1][len(r9[130][1])-5:len(r9[130][1])]

print(r9[55])
print(r9[56])
print(r9[62])
print(r9[63])
print(r9[109])
print(r9[110])
print(r9[128])
print(r9[129])
print(r9[130])


r10[55][2]=ip+r10[55][2][len(r10[55][2])-5:len(r10[55][2])]
r10[56][2]=ip+r10[56][2][len(r10[56][2])-5:len(r10[56][2])]
r10[62][2]=ip+r10[62][2][len(r10[62][2])-5:len(r10[62][2])]
r10[63][2]=ip+r10[63][2][len(r10[63][2])-5:len(r10[63][2])]
r10[124][1]=ip+r10[124][1][len(r10[124][1])-5:len(r10[124][1])]
r10[125][1]=ip+r10[125][1][len(r10[125][1])-5:len(r10[125][1])]

print(r10[55])
print(r10[56])
print(r10[62])
print(r10[63])
print(r10[124])
print(r10[125])


r1n=""
r2n=""
r3n=""
r4n=""
r5n=""
r6n=""
r7n=""
r8n=""
r9n=""
r10n=""
k=0
while(k<len(r1)):
	r1n+=" ".join(r1[k])+"\n"
	k=k+1
k=0
while(k<len(r2)):
	r2n+=" ".join(r2[k])+"\n"
	k=k+1
k=0
while(k<len(r3)):
	r3n+=" ".join(r3[k])+"\n"
	k=k+1
k=0
while(k<len(r4)):
	r4n+=" ".join(r4[k])+"\n"
	k=k+1
k=0
while(k<len(r5)):
	r5n+=" ".join(r5[k])+"\n"
	k=k+1
k=0
while(k<len(r6)):
	r6n+=" ".join(r6[k])+"\n"
	k=k+1
k=0
while(k<len(r7)):
	r7n+=" ".join(r7[k])+"\n"
	k=k+1
k=0
while(k<len(r8)):
	r8n+=" ".join(r8[k])+"\n"
	k=k+1
k=0
while(k<len(r9)):
	r9n+=" ".join(r9[k])+"\n"
	k=k+1
k=0
while(k<len(r10)):
	r10n+=" ".join(r10[k])+"\n"
	k=k+1
f=open('r1','w')
f.write(r1n)
f.close()

f=open('r2','w')
f.write(r2n)
f.close()

f=open('r3','w')
f.write(r3n)
f.close()

f=open('r4','w')
f.write(r4n)
f.close()

f=open('r5','w')
f.write(r5n)
f.close()

f=open('r6','w')
f.write(r6n)
f.close()

f=open('r7','w')
f.write(r7n)
f.close()

f=open('r8','w')
f.write(r8n)
f.close()

f=open('r9','w')
f.write(r9n)
f.close()

f=open('r10','w')
f.write(r10n)
f.close()
print (anti)

k=0
os.system("python3 r1.py "+ips[9] +" "+ str(10))
os.system("python3 r1.py "+ips[8] +" "+ str(9))
os.system("python3 r1.py "+ips[6] +" "+ str(7))
os.system("python3 r1.py "+ips[4] +" "+ str(5))
os.system("python3 r1.py "+ips[2] +" "+ str(3))
os.system("python3 r1.py "+ips[3] +" "+ str(4))
os.system("python3 r1.py "+ips[7] +" "+ str(8))
os.system("python3 r1.py "+ips[5] +" "+ str(6))
os.system("python3 r1.py "+ips[1] +" "+ str(2))
os.system("python3 r1.py "+ips[0] +" "+ str(1))


#HOST = "".join(ips[0])
#print (ips[0])
#tn=telnetlib.Telnet(HOST)
#tn.read_until(b"Username: ")
#tn.write(b'cisco' + b"\n")
#tn.read_until(b"Password: ")
#tn.write(b'cisco'+b"\n")
#tn.write(b"en\n")
#tn.write(b"cisco\n")
#tn.write(b"copy tftp: startup-config\n")
#tn.write(b"192.168.1.1\n")
#tn.write(b"r1\n")
#tn.write(b"\n")
#tn.write(b"exit\n")
#tn.read_until(b'',3)
#tn.close()
#print(tn.read_all().decode('ascii'))
